local random_module = require("Random-Module.src.random")

assert(random_module.isRandomProcess("-3Nvdg7g9S7ly-2scR8TtcY3QmIwtl_Gx5PDREJssiA"), "Test failed")
print("All tests passed!")